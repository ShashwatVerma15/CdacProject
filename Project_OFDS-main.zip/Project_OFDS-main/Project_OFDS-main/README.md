# Project_OFDS
Online Food Ordering Service
	
Online food delivery service is a web-based application that allows users to order food online. 
The system typically consists of two main components: a front-end user interface that allows customers to browse menus, select items, and place orders, and a back-end management system that handles order processing, restaurant management, and delivery logistics. 
The system will be easy to use, secure, and scalable to accommodate future growth.

USECASE DIAGRAMS :-

![UseCaseDiagram1](https://user-images.githubusercontent.com/52243796/224558581-18425ebc-d3d0-4a8f-a06e-788cc6146002.jpg)

![UseCaseDiagram2](https://user-images.githubusercontent.com/52243796/224559664-832f4a2e-e4cc-45f4-b71f-153f22585d23.JPG)

![UseCaseDiagram3](https://user-images.githubusercontent.com/52243796/224558586-7a072f2d-ecd0-40b0-97f3-494b2afdb629.jpg)
